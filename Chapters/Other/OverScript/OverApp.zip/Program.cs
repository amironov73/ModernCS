﻿using System;
using System.IO;
using System.Linq;

namespace OverScript;

internal static class Program
{
    static readonly System.Reflection.Assembly ExecutingAssembly = System.Reflection.Assembly.GetExecutingAssembly();
    public static readonly string OverScriptDir = Path.GetDirectoryName (ExecutingAssembly.Location);
    public static readonly string ModulesDir = Path.Combine (OverScriptDir, "modules");
    
    public static void Main 
        (
            string[] args
        )
    {
        if (args.Length < 1)
        {
            return;
        }

        try
        {
            var scriptFile = args[0];
            var scriptArgs = args.Skip (1).ToArray();
            var script = new Script (scriptFile, LoadingProgressChanged);
            var exec = new Executor (script);
            exec.Execute (scriptArgs);
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine (exception);
        }
    }

    private static void LoadingProgressChanged 
        (
            object sender, 
            int step
        )
    {
        Console.WriteLine(step < 0 ? "completed." : $"[{new string('#', step).PadRight (Script.LoadingSteps, '-')}]");
    }
    
}

